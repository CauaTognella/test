const soma = require('../javascript/soma');
test('soma -5 + -4 é retornar -9', () =>{
 expect(soma(-5 , -4)).toBe(-9);
 
})
test('soma de -5 + 4 é retornar -1', () =>{
 expect(soma(-5 , 4)).toBe(-1);})

test('soma de 5 + -4 é retornar 1', () =>{
    expect(soma(5 , -4)).toBe(1);})

test('soma de 565 + 41240 é retornar 41805', () =>{
    expect(soma(565 , 41240)).toBe(41805);
})