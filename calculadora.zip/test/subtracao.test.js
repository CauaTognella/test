const subtracao = require('../javascript/subtracao');
test('soma 5 - 2 é retornar 3', () => {
    expect(subtracao(5, 2)).toBe(3);
});

test('soma de 10 - 4 é retornar 6', () => {
    expect(subtracao(10, 4)).toBe(6);
}
);

test('soma de -5 - -5 é retornar 0', () => {
    expect(subtracao(-5, -5)).toBe(0);
}
);

test('soma de 0 - 4 é retornar -4', () => {
    expect(subtracao(0, 4)).toBe(-4);
});
