const divisao = require('../javascript/divisao');
test('divisao 6 / 2 é retornar 3', () =>{
 expect(divisao(6 , 2)).toBe(3);
 })
test('divisao 5 / 2 é retornar 2.5', () =>{
    expect(divisao(10 , 2)).toBe(5);
    })

test('divisao 5 / 0 é retornar erro', () =>{
    expect(divisao(5 , 0)).toBe(Infinity);
    })

test('divisao -10 / -2 é retornar 2', () =>{
    expect(divisao(-10 , -2)).toBe(5);
    })

 