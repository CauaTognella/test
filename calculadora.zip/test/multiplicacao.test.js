const multiplicacao = require('../javascript/multiplicacao');
test('multiplicacao 6 * 2 é retornar 12', () =>{
 expect(multiplicacao(6 , 2)).toBe(12);
 })

test('multiplicacao -5 * 2 é retornar -10', () =>{
    expect(multiplicacao(-5 , 2)).toBe(-10);
    })

test('multiplicacao 5 * 0 é retornar 0', () =>{
    expect(multiplicacao(5 , 0)).toBe(0);
    })

test('multiplicacao -10 * -2 é retornar 20', () =>{
    expect(multiplicacao(-10 , -2)).toBe(20);
    })


 