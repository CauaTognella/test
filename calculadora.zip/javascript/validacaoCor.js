export function aplicarCorElemento(elemento, valor) {
  elemento.classList.remove('positivo', 'negativo');
  if (typeof valor !== 'number' || Number.isNaN(valor) || valor === 0) return;
  if (valor > 0) elemento.classList.add('positivo');
  if (valor < 0) elemento.classList.add('negativo');
  
}

export function formatarResultado(valor) {
  // Formata para mostrar até 10 casas decimais, removendo zeros finais
  if (!isFinite(valor)) return String(valor);
  return Number.isFinite(valor) ? Number(valor.toFixed(10)).toString() : String(valor);
}
