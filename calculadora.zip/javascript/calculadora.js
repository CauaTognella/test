import { soma } from './soma.js';
import { subtracao } from './subtracao.js';
import { multiplicacao } from './multiplicacao.js';
import { divisao } from './divisao.js';



document.addEventListener('DOMContentLoaded', () => {
  const botao = document.getElementById('calcular');
  const num1 = document.getElementById('num1');
  const num2 = document.getElementById('num2');
  const operacao = document.getElementById('operacao');
  const resultado = document.getElementById('resultado');
  

  botao.addEventListener('click', (event) => {
    event.preventDefault(); // impede recarregar página

    const n1 = parseFloat(num1.value);
    const n2 = parseFloat(num2.value);
    let res = 0;

    if (isNaN(n1) || isNaN(n2)) {
      resultado.textContent = 'Preencha os dois números!';
      resultado.style.color = 'red';
      return;
    }

    switch (operacao.value) {
      case 'soma': res = soma(n1, n2); break;
      case 'subtracao': res = subtracao(n1, n2); break;
      case 'multiplicacao': res = multiplicacao(n1, n2); break;
      case 'divisao': res = divisao(n1, n2); break;
            default:
        resultado.textContent = 'Operação inválida';
       
        return;
    }

    
    
    resultado.innerHTML = res;
  });
});
