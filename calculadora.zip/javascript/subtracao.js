function subtracao(a, b) {
  return a - b;
}
module.exports = subtracao ;