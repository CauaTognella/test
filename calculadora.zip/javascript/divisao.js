function divisao(a, b) {
  return a / b;
}
module.exports =  divisao ;