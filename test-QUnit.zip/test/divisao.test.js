const divisao = require('../javascript/divisao');

QUnit.module('divisao', () => {
  QUnit.test('6 / 2 = 3', (assert) => {
    assert.equal(divisao(6, 2), 3);
  });

  QUnit.test('10 / 2 = 5', (assert) => {
    assert.equal(divisao(10, 2), 5);
  });

  QUnit.test('5 / 0 = Infinity', (assert) => {
    assert.equal(divisao(5, 0), Infinity);
  });

  QUnit.test('-10 / -2 = 5', (assert) => {
    assert.equal(divisao(-10, -2), 5);
  });
});
