const multiplicacao = require('../javascript/multiplicacao');

QUnit.module('multiplicacao', () => {
  QUnit.test('100 * 200 = 20000', (assert) => {
    assert.equal(multiplicacao(100, 200), 20000);
  });

  QUnit.test('1 * 2 = 2', (assert) => {
    assert.equal(multiplicacao(1, 2), 2);
  });

  QUnit.test('13 * 650 = 8450', (assert) => {
    assert.equal(multiplicacao(13, 650), 8450);
  });

  QUnit.test('5 * 20 = 100', (assert) => {
    assert.equal(multiplicacao(5, 20), 100);
  });

  QUnit.test('0 * 1000 = 0', (assert) => {
    assert.equal(multiplicacao(0, 1000), 0);
  });
});
