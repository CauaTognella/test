const subtracao = require('../javascript/subtracao');

QUnit.module('subtracao', () => {
  QUnit.test('5 - 2 = 3', (assert) => {
    assert.equal(subtracao(5, 2), 3);
  });

  QUnit.test('10 - 4 = 6', (assert) => {
    assert.equal(subtracao(10, 4), 6);
  });

  QUnit.test('-5 - -5 = 0', (assert) => {
    assert.equal(subtracao(-5, -5), 0);
  });

  QUnit.test('0 - 4 = -4', (assert) => {
    assert.equal(subtracao(0, 4), -4);
  });
});
