const soma = require('../javascript/soma');

QUnit.module('soma', () => {
  QUnit.test('100 + 200 = 300', (assert) => {
    assert.equal(soma(100, 200), 300);
  });

  QUnit.test('1 + 2 = 3', (assert) => {
    assert.equal(soma(1, 2), 3);
  });

  QUnit.test('13 + 650 = 663', (assert) => {
    assert.equal(soma(13, 650), 663);
  });

  QUnit.test('1 + 6 = 7', (assert) => {
    assert.equal(soma(1, 6), 7);
  });
});
